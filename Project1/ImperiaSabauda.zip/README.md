## How to run the script
The knn.py script can be run from the command line using the following commands:
- ```python knn.py``` This will run the model with our chosen best configuration (k=23, p=5)
- ```python knn.py [k] [p]``` This will run the model using the given k and p values